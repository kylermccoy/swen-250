// C (no pointers) Practicum
// SWEN-250
// Larry Kiser Feb. 13, 2018
//             New first no pointers practicum without structs

// cpracticum functions
int count_number_of_numeric_characters( char mystring[] ) ;
void convert_to_upper_case( char mystring[] ) ;
char range_test( int value, int lower_limit, int upper_limit ) ;
int fix_bad_code( int numbers[], int number_to_add ) ;
